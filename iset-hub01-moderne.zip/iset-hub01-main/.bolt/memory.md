# Project memory

## Product intent & audience

- Student housing & colocation platform, likely targeting students near ISET (Institut Supérieur des Études Technologiques, Tunisia).
- Listings include rental properties (apartments, student rooms, Mediterranean houses) with contact and visit-booking actions.
- UI language is French.

## Brand personality & voice

- Warm, authentic, student-friendly; avoids overly polished "catalogue" aesthetics.
- Content favors natural, real-world photography over idealized 3D renders.

## Visual design & UX direction

- Stack: Vite + React, Tailwind CSS, shadcn/ui, Lucide React icons. Do not add other UI/icon packages unless explicitly requested.
- Property card detail modal must be fully opaque (`bg-white`) with dark blurred overlay (`bg-black/60 backdrop-blur-sm`); avoid `bg-background` or any translucent dialog surface.
- Modal layout: hero photo with rounded corners at top, prominent price badge, location, room count, amenities as small clear badges (Wi-Fi, climatisation, meublé), distance to ISET, and a fixed action button at bottom ("Contacter le propriétaire" / "Réserver une visite").
- Property photos use real Pexels image URLs already present in the project; prefer warm, natural interiors. Do not invent new image URLs.
- Responsive across mobile and desktop.

## Decisions, constraints & rationale

- Added amenities and distance-to-ISET fields to listings so the modal doesn't invent data.
- Replaced previous 3D/perfect-studio-style photos with existing Pexels URLs chosen for a more natural, Mediterranean student-housing feel.
- Modal styling corrected to guarantee readability (opaque white dialog, dark blurred overlay) after transparency issues with `bg-background`.
- Six property listings currently exist with updated photos and stored metadata.

## Open questions & assumptions

- Whether listings are backed by a real database/API or static/mock data is not fully confirmed (response mentions "enregistrées en base").
- Full app scope beyond Logement & Colocation section is unknown.
- Preferred contact/booking flow (email, form, WhatsApp, etc.) not specified.