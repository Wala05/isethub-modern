/*
# Official club logos

1. Modified Tables
- `clubs`: `logo_url` is set for the clubs whose official logo was provided.

2. Important notes
- Enactus, MOVE, Outdoor, Radio ISET / ISET FM and SWUG Club use the logo files stored in the public folder.
- Zero Campus, Arena and ArtiVision keep their icon until their logos are provided.
- Re-running this migration only updates rows whose logo differs.
*/

UPDATE public.clubs SET logo_url = '/enactus.png' WHERE slug = 'enactus' AND logo_url IS DISTINCT FROM '/enactus.png';
UPDATE public.clubs SET logo_url = '/move.png' WHERE slug = 'move' AND logo_url IS DISTINCT FROM '/move.png';
UPDATE public.clubs SET logo_url = '/outdoor.png' WHERE slug = 'outdoor' AND logo_url IS DISTINCT FROM '/outdoor.png';
UPDATE public.clubs SET logo_url = '/radio_iset.png' WHERE slug = 'radio-iset-fm' AND logo_url IS DISTINCT FROM '/radio_iset.png';
UPDATE public.clubs SET logo_url = '/swug.png' WHERE slug = 'swug-club' AND logo_url IS DISTINCT FROM '/swug.png';
