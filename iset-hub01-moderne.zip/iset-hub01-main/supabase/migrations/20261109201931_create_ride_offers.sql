/*
# Carpool ride offers

1. New Tables
- `ride_offers`: shared rides between Djerba towns and the ISET campus, shown on the Vie étudiante page.
  - `id` (uuid, primary key, fixed values for seeded rows)
  - `origin` (text): departure town
  - `destination` (text): arrival place
  - `departure_time` (time): departure hour
  - `days_label` (text): days the ride runs, for example Lun - Ven
  - `note` (text): extra detail such as the return time
  - `seats_left` (integer): seats still available, never negative
  - `price_dt` (integer): price per trip in dinars
  - `created_at` (timestamptz)

2. Security
- Row level security enabled on `ride_offers`.
- Anonymous and signed-in visitors can read ride offers (public catalogue, no sign-in in this app).
- No write access is granted to the browser.

3. Important notes
- Seeded rows use fixed ids and `ON CONFLICT DO NOTHING`, so re-running this migration does not duplicate them.
*/

CREATE TABLE IF NOT EXISTS ride_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  origin text NOT NULL,
  destination text NOT NULL,
  departure_time time NOT NULL,
  days_label text NOT NULL,
  note text NOT NULL,
  seats_left integer NOT NULL CHECK (seats_left >= 0),
  price_dt integer NOT NULL CHECK (price_dt > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE ride_offers ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON ride_offers TO anon, authenticated;

DROP POLICY IF EXISTS "public_select_ride_offers" ON ride_offers;
CREATE POLICY "public_select_ride_offers" ON ride_offers FOR SELECT
  TO anon, authenticated USING (true);

INSERT INTO ride_offers (id, origin, destination, departure_time, days_label, note, seats_left, price_dt) VALUES
  ('5a2e9b10-0001-4b00-9000-000000000001', 'Houmt Souk', 'ISET Djerba', '07:30', 'Lun - Ven', 'Départ de la place centrale de Houmt Souk', 3, 2),
  ('5a2e9b10-0002-4b00-9000-000000000002', 'Midoun', 'ISET Djerba', '07:45', 'Tous les jours', 'Retour possible à 17:00', 2, 3),
  ('5a2e9b10-0003-4b00-9000-000000000003', 'ISET Djerba', 'Houmt Souk', '17:15', 'Mercredi', 'Départ après les cours', 2, 2),
  ('5a2e9b10-0004-4b00-9000-000000000004', 'Djerba Ajim', 'ISET Djerba', '07:50', 'Lun - Sam', 'Trajet direct, sans arrêt', 0, 1)
ON CONFLICT (id) DO NOTHING;
