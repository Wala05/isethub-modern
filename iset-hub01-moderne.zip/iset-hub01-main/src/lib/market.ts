export type MarketItem = {
  id: string;
  title: string;
  short: string;
  price: string;
  seller: string;
  condition: string;
  description: string;
  image: string;
};

export const marketItems: MarketItem[] = [
  {
    id: 'calc-casio',
    title: 'Calculatrice Casio Graph 35+',
    short: 'Très bon état, avec housse',
    price: '85 DT',
    seller: 'Meriem',
    condition: 'Très bon état',
    description: 'Calculatrice graphique Casio Graph 35+, idéale pour les cours de mathématiques et de physique. Livrée avec sa housse de protection et sa notice. Piles récemment changées, tous les modes de calcul fonctionnent parfaitement (graphiques, statistiques, équations).',
    image: 'https://images.pexels.com/photos/220301/pexels-photo-220301.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'manuel-compta',
    title: 'Manuel de comptabilité S3',
    short: 'Édition 2024, annotations utiles',
    price: '20 DT',
    seller: 'Ahmed',
    condition: 'Bon état',
    description: 'Manuel de comptabilité pour le semestre 3, édition 2024. Les annotations au crayon des années précédentes facilitent la révision des chapitres clés (bilan, journal, comptes de résultat). Quelques pages marquées mais aucune page manquante ni déchirée.',
    image: 'https://images.pexels.com/photos/11911071/pexels-photo-11911071.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'kit-mecano',
    title: 'Blouse + lunettes de protection',
    short: 'Kit mécanique, taille M',
    price: '35 DT',
    seller: 'Sami',
    condition: 'Bon état',
    description: 'Ensemble complet pour les TP de mécanique et de laboratoire : blouse en coton taille M lavée plusieurs fois mais sans tache ni accroc, et lunettes de protection à verres transparents anti-rayures. Conformes aux consignes de sécurité de l\'ISET.',
    image: 'https://images.pexels.com/photos/8352127/pexels-photo-8352127.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];
