import { supabase } from './supabase';

export type ClubCategory = 'Culturel' | 'Scientifique' | 'Sportif' | 'Environnement' | 'Entrepreneuriat';

export type Club = {
  id: string;
  slug: string;
  name: string;
  categories: ClubCategory[];
  description: string;
  logo_url: string | null;
  founded_year: number | null;
  president_name: string | null;
  academic_supervisor: string | null;
};

export type ClubEvent = {
  id: string;
  title: string;
  event_date: string;
  location: string;
  capacity: number;
  description: string;
  club_id: string | null;
};

const clubColumns = 'id, slug, name, categories, description, logo_url, founded_year, president_name, academic_supervisor';
const eventColumns = 'id, title, event_date, location, capacity, description, club_id';

export function formatEventParts(iso: string) {
  const date = new Date(iso);
  return {
    day: date.toLocaleDateString('fr-FR', { day: '2-digit' }),
    month: date.toLocaleDateString('fr-FR', { month: 'short' }).replace('.', ''),
    weekday: date.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }),
    time: date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
  };
}

export async function fetchClubs(): Promise<Club[]> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase.from('clubs').select(clubColumns).order('name');
  if (error) throw error;
  return (data ?? []) as Club[];
}

export async function fetchUpcomingEvents(): Promise<ClubEvent[]> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase
    .from('events')
    .select(eventColumns)
    .gte('event_date', new Date().toISOString())
    .order('event_date', { ascending: true })
    .limit(60);
  if (error) throw error;
  return (data ?? []) as ClubEvent[];
}
