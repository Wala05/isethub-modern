import { Atom, Dumbbell, Leaf, Mountain, Palette, Radio, Rocket, Ruler, Users, type LucideIcon } from 'lucide-react';
import type { ClubCategory } from '@/lib/clubs';

export const categoryStyles: Record<ClubCategory, string> = {
  Culturel: 'bg-[#fff4df] text-[#8a5300]',
  Scientifique: 'bg-[#eaf5fc] text-[#0f5b96]',
  Sportif: 'bg-[#e8f7f0] text-[#11704a]',
  Environnement: 'bg-[#eef8e6] text-[#3f6b12]',
  Entrepreneuriat: 'bg-[#fdeef0] text-[#a3324a]',
};

export const clubVisuals: Record<string, { icon: LucideIcon; tile: string }> = {
  'zero-campus-club': { icon: Leaf, tile: 'bg-[#2f7d46]' },
  arena: { icon: Dumbbell, tile: 'bg-[#b8501f]' },
  artivision: { icon: Palette, tile: 'bg-[#b83a6e]' },
  enactus: { icon: Rocket, tile: 'bg-[#0f6f7d]' },
  move: { icon: Atom, tile: 'bg-[#126cb1]' },
  outdoor: { icon: Mountain, tile: 'bg-[#4d6f12]' },
  'radio-iset-fm': { icon: Radio, tile: 'bg-[#8a5300]' },
  'swug-club': { icon: Ruler, tile: 'bg-[#021d33]' },
};

export const fallbackClubVisual = { icon: Users, tile: 'bg-slate-600' };

export function getClubVisual(slug: string) {
  return clubVisuals[slug] ?? fallbackClubVisual;
}
