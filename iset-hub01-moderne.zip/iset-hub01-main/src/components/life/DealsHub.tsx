import { useEffect, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { fetchLifeSpots, type LifeSpot } from '@/lib/life';
import { LifeSpotCard } from './LifeSpotCard';
import { FoodSection } from '@/components/food/FoodSection';

type Tab = 'tous' | 'restos' | 'etude' | 'services';

const tabs: { key: Tab; label: string }[] = [
  { key: 'tous', label: 'Tous' },
  { key: 'restos', label: 'Restaurants & Snacks' },
  { key: 'etude', label: "Coworking & Cafés d'étude" },
  { key: 'services', label: 'Services & Imprimeries' },
];

export function DealsHub() {
  const [tab, setTab] = useState<Tab>('tous');
  const [spots, setSpots] = useState<LifeSpot[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let active = true;
    fetchLifeSpots()
      .then((list) => {
        if (!active) return;
        setSpots(list);
        setStatus('ready');
      })
      .catch(() => {
        if (active) setStatus('error');
      });
    return () => { active = false; };
  }, [reloadKey]);

  const studySpots = spots.filter((spot) => spot.category === 'Etude');
  const serviceSpots = spots.filter((spot) => spot.category === 'Service');

  const showFood = tab === 'tous' || tab === 'restos';
  const showStudy = tab === 'tous' || tab === 'etude';
  const showServices = tab === 'tous' || tab === 'services';

  return (
    <div>
      <div className="mb-8 flex gap-2 overflow-x-auto pb-1">
        {tabs.map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`h-10 shrink-0 rounded-full px-4 text-sm font-bold transition ${tab === key ? 'bg-[#021d33] text-white' : 'border border-slate-200 bg-white text-slate-600 hover:border-[#126cb1] hover:text-[#126cb1]'}`}
          >
            {label}
          </button>
        ))}
      </div>

      {status === 'error' && (
        <div className="mb-8 flex flex-col items-center rounded-2xl border border-red-100 bg-white p-10 text-center">
          <p className="font-black text-slate-700">Impossible de charger les cafés d'étude et les services pour le moment.</p>
          <button
            onClick={() => { setStatus('loading'); setReloadKey((key) => key + 1); }}
            className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-[#126cb1] px-5 text-sm font-black text-white transition hover:bg-[#0f5b96]"
          >
            <RotateCcw size={16} /> Réessayer
          </button>
        </div>
      )}

      {showFood && <FoodSection />}

      {showStudy && status !== 'error' && (
        <section className="mb-12">
          <h2 className="mb-5 text-xl font-black text-[#021d33]">Coworking & Cafés d'étude</h2>
          {studySpots.length === 0 && status === 'ready' ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm font-semibold text-slate-400">
              Aucun lieu d'étude pour le moment.
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {studySpots.map((spot) => <LifeSpotCard key={spot.id} spot={spot} />)}
            </div>
          )}
        </section>
      )}

      {showServices && status !== 'error' && (
        <section className="mb-12">
          <h2 className="mb-5 text-xl font-black text-[#021d33]">Services & Imprimeries</h2>
          {serviceSpots.length === 0 && status === 'ready' ? (
            <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm font-semibold text-slate-400">
              Aucun service pour le moment.
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {serviceSpots.map((spot) => <LifeSpotCard key={spot.id} spot={spot} />)}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
