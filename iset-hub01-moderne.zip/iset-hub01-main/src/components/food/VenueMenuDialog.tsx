import { useMemo, useState } from 'react';
import { Minus, Plus, ShoppingBag, Truck, Store as StoreIcon, CheckCircle2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import {
  CAMPUS_DELIVERY_FEE_DT,
  formatDinar,
  formatTime,
  isOpenNow,
  type FoodItem,
  type FoodVenue,
  type Fulfilment,
} from '@/lib/food';
import { CheckoutForm } from './CheckoutForm';

type VenueMenuDialogProps = {
  venue: FoodVenue;
  onClose: () => void;
};

type Step = 'menu' | 'checkout' | 'done';
type Confirmation = { orderId: string; totalDt: number; fulfilment: Fulfilment };

export function VenueMenuDialog({ venue, onClose }: VenueMenuDialogProps) {
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [fulfilment, setFulfilment] = useState<Fulfilment>('pickup');
  const [step, setStep] = useState<Step>('menu');
  const [confirmation, setConfirmation] = useState<Confirmation | null>(null);

  const availableItems = venue.food_items.filter((item) => item.available);
  const cart = useMemo(
    () => availableItems
      .filter((item) => (quantities[item.id] ?? 0) > 0)
      .map((item) => ({ item, quantity: quantities[item.id] })),
    [availableItems, quantities],
  );
  const itemCount = cart.reduce((sum, line) => sum + line.quantity, 0);
  const subtotal = cart.reduce((sum, line) => sum + line.item.price_dt * line.quantity, 0);
  const fee = fulfilment === 'campus_delivery' ? CAMPUS_DELIVERY_FEE_DT : 0;
  const open = isOpenNow(venue.opens_at, venue.closes_at);

  const setQuantity = (item: FoodItem, next: number) => {
    setQuantities((current) => ({ ...current, [item.id]: Math.min(Math.max(next, 0), 20) }));
  };

  return (
    <Dialog open onOpenChange={(value) => { if (!value) onClose(); }}>
      <DialogContent className="flex max-h-[90vh] w-[calc(100%-2rem)] max-w-2xl flex-col gap-0 overflow-hidden rounded-[1.5rem] p-0">
        <div className="flex items-start gap-4 border-b border-slate-100 p-5 sm:p-6">
          <img src={venue.image_url} alt="" className="h-16 w-16 shrink-0 rounded-2xl object-cover" />
          <div className="min-w-0 flex-1">
            <DialogTitle className="truncate text-xl font-black text-[#021d33]">{venue.name}</DialogTitle>
            <DialogDescription className="mt-1 text-sm font-semibold text-slate-500">
              {venue.area} · {formatTime(venue.opens_at)} - {formatTime(venue.closes_at)} ·{' '}
              <span className={open ? 'text-emerald-700' : 'text-slate-500'}>{open ? 'Ouvert maintenant' : 'Fermé pour le moment'}</span>
            </DialogDescription>
          </div>
        </div>

        {step === 'menu' && (
          <>
            <ul className="flex-1 divide-y divide-slate-100 overflow-y-auto px-5 sm:px-6">
              {venue.food_items.map((item) => {
                const quantity = quantities[item.id] ?? 0;
                return (
                  <li key={item.id} className="flex items-center gap-4 py-4">
                    <img src={item.image_url} alt="" loading="lazy" className="h-16 w-16 shrink-0 rounded-xl object-cover" />
                    <div className="min-w-0 flex-1">
                      <p className="font-black text-[#021d33]">{item.name}</p>
                      <p className="mt-0.5 line-clamp-2 text-sm leading-5 text-slate-500">{item.description}</p>
                      <p className="mt-1.5 text-sm font-black text-[#126cb1]">{formatDinar(item.price_dt)}</p>
                    </div>
                    {item.available ? (
                      <div className="flex shrink-0 items-center gap-2 rounded-xl border border-slate-200 p-1">
                        <button
                          onClick={() => setQuantity(item, quantity - 1)}
                          disabled={quantity === 0}
                          aria-label={`Retirer ${item.name}`}
                          className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-600 transition hover:bg-slate-100 disabled:opacity-30"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="w-6 text-center font-black tabular-nums text-[#021d33]">{quantity}</span>
                        <button
                          onClick={() => setQuantity(item, quantity + 1)}
                          disabled={quantity >= 20}
                          aria-label={`Ajouter ${item.name}`}
                          className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#126cb1] text-white transition hover:bg-[#0f5b96] disabled:opacity-40"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                    ) : (
                      <span className="shrink-0 rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-500">Indisponible</span>
                    )}
                  </li>
                );
              })}
            </ul>

            <div className="border-t border-slate-100 bg-white p-5 sm:p-6">
              <p className="text-xs font-black uppercase tracking-[.14em] text-slate-400">Mode de récupération</p>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                <FulfilmentOption
                  active={fulfilment === 'pickup'}
                  icon={StoreIcon}
                  title="Retrait sur place"
                  detail="Gratuit, à récupérer au restaurant"
                  onSelect={() => setFulfilment('pickup')}
                />
                <FulfilmentOption
                  active={fulfilment === 'campus_delivery'}
                  icon={Truck}
                  title="Livraison campus ISET"
                  detail={venue.delivers_to_campus ? `+${CAMPUS_DELIVERY_FEE_DT} DT de livraison` : 'Non disponible pour ce restaurant'}
                  disabled={!venue.delivers_to_campus}
                  onSelect={() => setFulfilment('campus_delivery')}
                />
              </div>

              <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <p className="flex items-center gap-2 text-sm font-semibold text-slate-600">
                  <ShoppingBag size={17} className="text-[#126cb1]" />
                  {itemCount === 0 ? 'Panier vide' : `${itemCount} ${itemCount > 1 ? 'articles' : 'article'} · ${formatDinar(subtotal + fee)}`}
                </p>
                <button
                  onClick={() => setStep('checkout')}
                  disabled={itemCount === 0}
                  className="h-11 rounded-xl bg-[#fab757] px-6 text-sm font-black text-[#021d33] transition hover:brightness-95 active:scale-[.98] disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-500"
                >
                  Passer commande
                </button>
              </div>
            </div>
          </>
        )}

        {step === 'checkout' && (
          <CheckoutForm
            venueId={venue.id}
            cart={cart}
            fulfilment={fulfilment}
            feeDt={fee}
            subtotalDt={subtotal}
            onBack={() => setStep('menu')}
            onPlaced={(result) => {
              setConfirmation({ ...result, fulfilment });
              setQuantities({});
              setStep('done');
            }}
          />
        )}

        {step === 'done' && confirmation && (
          <div className="flex flex-col items-center p-8 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
              <CheckCircle2 size={30} />
            </div>
            <p className="mt-5 text-xl font-black text-[#021d33]">Commande envoyée</p>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              {confirmation.fulfilment === 'campus_delivery'
                ? `Ta commande sera livrée sur le campus de l'ISET Djerba. Total : ${formatDinar(confirmation.totalDt)}.`
                : `Ta commande est à récupérer chez ${venue.name}. Total : ${formatDinar(confirmation.totalDt)}.`}
            </p>
            <p className="mt-4 rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-black tracking-wider text-slate-600">
              N° {confirmation.orderId.slice(0, 8).toUpperCase()}
            </p>
            <button
              onClick={onClose}
              className="mt-6 h-11 w-full rounded-xl bg-[#126cb1] text-sm font-black text-white transition hover:bg-[#0f5b96] sm:w-auto sm:px-8"
            >
              Fermer
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

type FulfilmentOptionProps = {
  active: boolean;
  icon: typeof Truck;
  title: string;
  detail: string;
  disabled?: boolean;
  onSelect: () => void;
};

function FulfilmentOption({ active, icon: Icon, title, detail, disabled, onSelect }: FulfilmentOptionProps) {
  return (
    <button
      onClick={onSelect}
      disabled={disabled}
      aria-pressed={active}
      className={`flex min-h-16 items-center gap-3 rounded-xl border p-3 text-left transition disabled:cursor-not-allowed disabled:opacity-50 ${active ? 'border-[#126cb1] bg-[#eaf5fc]' : 'border-slate-200 bg-white hover:border-slate-300'}`}
    >
      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${active ? 'bg-[#126cb1] text-white' : 'bg-slate-100 text-slate-500'}`}>
        <Icon size={17} />
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-black text-[#021d33]">{title}</span>
        <span className="block text-xs font-semibold text-slate-500">{detail}</span>
      </span>
    </button>
  );
}
