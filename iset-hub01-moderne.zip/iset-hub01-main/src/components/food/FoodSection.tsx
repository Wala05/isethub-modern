import { useEffect, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { fetchFoodVenues, type FoodVenue } from '@/lib/food';
import { VenueCard } from './VenueCard';
import { VenueMenuDialog } from './VenueMenuDialog';

export function FoodSection() {
  const [venues, setVenues] = useState<FoodVenue[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [reloadKey, setReloadKey] = useState(0);
  const [menuVenueId, setMenuVenueId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchFoodVenues()
      .then((list) => {
        if (!active) return;
        setVenues(list);
        setStatus('ready');
      })
      .catch(() => {
        if (active) setStatus('error');
      });
    return () => { active = false; };
  }, [reloadKey]);

  const menuVenue = venues.find((venue) => venue.id === menuVenueId) ?? null;

  if (status === 'loading') {
    return (
      <section className="mb-12">
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="h-96 animate-pulse rounded-[1.5rem] border border-slate-200 bg-white" />
          ))}
        </div>
      </section>
    );
  }

  if (status === 'error') {
    return (
      <section className="mb-12">
        <div className="flex flex-col items-center rounded-2xl border border-red-100 bg-white p-10 text-center">
          <p className="font-black text-slate-700">Impossible de charger les restaurants pour le moment.</p>
          <p className="mt-2 text-sm text-slate-400">Vérifie ta connexion puis réessaie.</p>
          <button
            onClick={() => { setStatus('loading'); setReloadKey((key) => key + 1); }}
            className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-[#126cb1] px-5 text-sm font-black text-white transition hover:bg-[#0f5b96]"
          >
            <RotateCcw size={16} /> Réessayer
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="mb-12">
      {venues.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm font-semibold text-slate-400">
          Aucun restaurant pour le moment.
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {venues.map((venue) => (
            <VenueCard key={venue.id} venue={venue} onOpenMenu={() => setMenuVenueId(venue.id)} />
          ))}
        </div>
      )}

      {menuVenue && <VenueMenuDialog venue={menuVenue} onClose={() => setMenuVenueId(null)} />}
    </section>
  );
}
