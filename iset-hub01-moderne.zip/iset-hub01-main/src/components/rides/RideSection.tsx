import { useEffect, useState } from 'react';
import { Car, RotateCcw } from 'lucide-react';
import { fetchRideOffers, type RideOffer } from '@/lib/rides';
import { CommunityHeader } from '@/components/community/CommunityHeader';
import { RideCard } from './RideCard';

type RideSectionProps = { notify: (message: string) => void };

export function RideSection({ notify }: RideSectionProps) {
  const [rides, setRides] = useState<RideOffer[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let active = true;
    fetchRideOffers()
      .then((list) => {
        if (!active) return;
        setRides(list);
        setStatus('ready');
      })
      .catch(() => {
        if (active) setStatus('error');
      });
    return () => { active = false; };
  }, [reloadKey]);

  const header = (
    <CommunityHeader
      icon={Car}
      title="Les trajets sont plus simples à plusieurs"
      subtitle={status === 'ready' ? `${rides.length} trajets proposés` : undefined}
      cta="Proposer un trajet"
      onCta={() => notify('Connecte-toi pour proposer un trajet en quelques secondes.')}
    />
  );

  if (status === 'loading') {
    return (
      <>
        {header}
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="h-80 animate-pulse rounded-[1.5rem] border border-slate-200 bg-white" />
          ))}
        </div>
      </>
    );
  }

  if (status === 'error') {
    return (
      <>
        {header}
        <div className="flex flex-col items-center rounded-2xl border border-red-100 bg-white p-10 text-center">
          <p className="font-black text-slate-700">Impossible de charger les trajets pour le moment.</p>
          <p className="mt-2 text-sm text-slate-400">Vérifie ta connexion puis réessaie.</p>
          <button
            onClick={() => { setStatus('loading'); setReloadKey((key) => key + 1); }}
            className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-[#126cb1] px-5 text-sm font-black text-white transition hover:bg-[#0f5b96]"
          >
            <RotateCcw size={16} /> Réessayer
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      {header}
      {rides.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm font-semibold text-slate-400">
          Aucun trajet proposé pour le moment.
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {rides.map((ride) => (
            <RideCard
              key={ride.id}
              ride={ride}
              onContact={() => notify('Message envoyé au conducteur.')}
            />
          ))}
        </div>
      )}
    </>
  );
}
