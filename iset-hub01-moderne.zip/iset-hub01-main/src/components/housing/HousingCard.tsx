import { BedDouble, MapPin } from 'lucide-react';
import type { HousingListing } from '@/lib/housing';

type HousingCardProps = {
  listing: HousingListing;
  onDetails: () => void;
  onContact: () => void;
};

export function HousingCard({ listing, onDetails, onContact }: HousingCardProps) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#126cb1]/10">
      <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
        <img
          src={listing.image_url}
          alt={`Photo de ${listing.title}`}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        <span className="absolute left-4 top-4 rounded-full bg-[#fab757] px-3 py-1.5 text-sm font-black text-[#021d33] shadow-lg">
          {listing.price_dt} DT / mois
        </span>
        <span className="absolute right-4 top-4 rounded-full bg-white/95 px-3 py-1 text-xs font-black text-[#021d33] shadow">
          {listing.property_type}
        </span>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="text-lg font-black leading-snug text-[#021d33]">{listing.title}</h3>
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm font-semibold text-slate-500">
          <span className="flex items-center gap-1.5"><MapPin size={15} className="text-[#126cb1]" /> {listing.neighborhood}</span>
          <span className="flex items-center gap-1.5"><BedDouble size={15} className="text-[#126cb1]" /> {listing.rooms} {listing.rooms > 1 ? 'pièces' : 'pièce'}</span>
        </div>
        <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-500">{listing.description}</p>
        <p className="mt-4 inline-flex w-fit rounded-lg bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700">{listing.available_label}</p>

        <div className="mt-auto grid grid-cols-2 gap-2 pt-5">
          <button
            onClick={onDetails}
            className="h-11 rounded-xl border border-slate-200 px-3 text-sm font-bold text-[#021d33] transition hover:border-[#126cb1] hover:text-[#126cb1] active:scale-[.98]"
          >
            Voir les détails
          </button>
          <button
            onClick={onContact}
            className="h-11 rounded-xl bg-[#126cb1] px-3 text-sm font-black text-white transition hover:bg-[#0f5b96] active:scale-[.98]"
          >
            Contacter
          </button>
        </div>
      </div>
    </article>
  );
}
