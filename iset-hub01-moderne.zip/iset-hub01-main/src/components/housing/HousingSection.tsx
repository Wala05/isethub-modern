import { useEffect, useState } from 'react';
import { Home, RotateCcw } from 'lucide-react';
import { fetchHousingListings, type HousingListing, type HousingType } from '@/lib/housing';
import { CommunityHeader } from '@/components/community/CommunityHeader';
import { HousingCard } from './HousingCard';
import { HousingDetailsDialog } from './HousingDetailsDialog';

type HousingSectionProps = { notify: (message: string) => void };

const filters: ('Tous' | HousingType)[] = ['Tous', 'Studio', 'Appartement', 'Colocation'];

export function HousingSection({ notify }: HousingSectionProps) {
  const [listings, setListings] = useState<HousingListing[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [reloadKey, setReloadKey] = useState(0);
  const [filter, setFilter] = useState<(typeof filters)[number]>('Tous');
  const [detailsId, setDetailsId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetchHousingListings()
      .then((list) => {
        if (!active) return;
        setListings(list);
        setStatus('ready');
      })
      .catch(() => {
        if (active) setStatus('error');
      });
    return () => { active = false; };
  }, [reloadKey]);

  const visible = filter === 'Tous' ? listings : listings.filter((listing) => listing.property_type === filter);
  const detailsListing = listings.find((listing) => listing.id === detailsId) ?? null;

  const header = (
    <CommunityHeader
      icon={Home}
      title="Trouver une coloc qui te ressemble"
      subtitle={status === 'ready' ? `${listings.length} annonces disponibles` : undefined}
      cta="Publier une annonce"
      onCta={() => notify('Connecte-toi pour publier en quelques secondes.')}
    />
  );

  if (status === 'loading') {
    return (
      <>
        {header}
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <div key={index} className="h-96 animate-pulse rounded-[1.5rem] border border-slate-200 bg-white" />
          ))}
        </div>
      </>
    );
  }

  if (status === 'error') {
    return (
      <>
        {header}
        <div className="flex flex-col items-center rounded-2xl border border-red-100 bg-white p-10 text-center">
          <p className="font-black text-slate-700">Impossible de charger les annonces pour le moment.</p>
          <p className="mt-2 text-sm text-slate-400">Vérifie ta connexion puis réessaie.</p>
          <button
            onClick={() => { setStatus('loading'); setReloadKey((key) => key + 1); }}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#126cb1] px-4 py-2.5 text-sm font-black text-white transition hover:bg-[#0f5b96]"
          >
            <RotateCcw size={16} /> Réessayer
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      {header}

      <div className="mb-6 flex gap-2 overflow-x-auto pb-1">
        {filters.map((item) => (
          <button
            key={item}
            onClick={() => setFilter(item)}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold transition ${filter === item ? 'bg-[#021d33] text-white' : 'border border-slate-200 bg-white text-slate-600 hover:border-[#126cb1] hover:text-[#126cb1]'}`}
          >
            {item}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm font-semibold text-slate-400">
          Aucune annonce de ce type pour le moment.
        </div>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((listing) => (
            <HousingCard
              key={listing.id}
              listing={listing}
              onDetails={() => setDetailsId(listing.id)}
              onContact={() => notify('Message envoyé au propriétaire.')}
            />
          ))}
        </div>
      )}

      {detailsListing && (
        <HousingDetailsDialog
          listing={detailsListing}
          onContact={() => notify('Message envoyé au propriétaire.')}
          onClose={() => setDetailsId(null)}
        />
      )}
    </>
  );
}
